import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { AllModulesService } from '../../all-modules.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { DomSanitizer,SafeStyle  } from '@angular/platform-browser';

//import {jsPDF} from "jspdf";
//import "jspdf-autotable";
// import * as jspdf from 'jspdf';
// import html2canvas from 'html2canvas';

@Component({
  selector: 'app-generate-slip',
  templateUrl: './generate-slip.component.html',
  styleUrls: ['./generate-slip.component.css']
})
export class GenerateSlipComponent implements OnInit {
  tableData: any;
  tableLen: any;
  dataSource: any;
  paginator: any;
  sd: any=[];
  companyName: string;
  address: string;
  loginData: string | string[];
  HttpClient: any;
  result: any;
  loader: boolean;
  public backgroundImg: SafeStyle;
  path=environment.apiEndpoint;
  netsalary:any;
  constructor(private sanitizer: DomSanitizer,private srvModuleService: AllModulesService,private http: HttpClient,public _service:AllModulesService,public router:Router) {
    console.log(this.router.getCurrentNavigation()?.extras.queryParams);
    //this.getCompany();
//this.sd=[];
    let param=this.router.getCurrentNavigation()?.extras.queryParams;
    if(param){
    this.dataSource=(param);
    console.log(this.dataSource);
    this.backgroundImg=this.dataSource.image;
    console.log(this.backgroundImg);
    

    for(let i=0;i<this.dataSource.Data.length;i++){
    this.sd.push(this.dataSource.Data[i]);
    console.log(this.dataSource.Data[i]);
    if(i==0){
this.netsalary=this.dataSource.Data[i].netSalary;
this.netsalary=Math.round(this.netsalary);
console.log(this.netsalary);
    }
  }
  //console.log(this.sd[0]);

    }
   }

  ngOnInit(): void {
this.companyName=localStorage.getItem('companyName')
this.address=localStorage.getItem('address')
//this.backgroundImg='http://localhost:5555/cmpimages/610Trishul-Logo(1).png'
console.log(this.backgroundImg)
 
  }
  downloadAsPDF(sectionToPrint){
    const printContents = document.getElementById(sectionToPrint).innerHTML;
    const originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.focus();
    window.print()
   
    
    window.close();
    document.body.innerHTML = originalContents;

  }


  
  a = [
    '',
    'One ',
    'Two ',
    'Three ',
    'Four ',
    'Five ',
    'Six ',
    'Seven ',
    'Eight ',
    'Nine ',
    'Ten ',
    'Eleven ',
    'Twelve ',
    'Thirteen ',
    'Fourteen ',
    'Fifteen ',
    'Sixteen ',
    'Seventeen ',
    'Eighteen ',
    'Nineteen '];

  b = [
    '',
    '',
    'Twenty',
    'Thirty',
    'Forty',
    'Fifty',
    'Sixty',
    'Seventy',
    'Eighty',
    'Ninety'];

    
  transform(value: any, args?: any): any {
    if (value) {
      let num: any = Number(value);
      if (num) {
        if ((num = num.toString()).length > 9)  { return 'We are not the Iron Bank, you can lower down the stakes :)'; }
        const n = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
        if (!n) {return ''; }
        let str = '';
        str += (Number(n[1]) !== 0) ? (this.a[Number(n[1])] || this.b[n[1][0]] + ' ' + this.a[n[1][1]]) + 'Crore ' : '';
        str += (Number(n[2]) !== 0) ? (this.a[Number(n[2])] || this.b[n[2][0]] + ' ' + this.a[n[2][1]]) + 'Lakh ' : '';
        str += (Number(n[3]) !== 0) ? (this.a[Number(n[3])] || this.b[n[3][0]] + ' ' + this.a[n[3][1]]) + 'Thousand ' : '';
        str += (Number(n[4]) !== 0) ? (this.a[Number(n[4])] || this.b[n[4][0]] + ' ' + this.a[n[4][1]]) + 'Hundred ' : '';
        str += (Number(n[5]) !== 0) ? ((str !== '') ? 'and ' : '') +
        (this.a[Number(n[5])] || this.b[n[5][0]] + ' ' +
        this.a[n[5][1]]) + 'Rupees' : '';
        return str;
      } else {
        return '';
      }
    } else {
      return '';
    }
  }
  
}
