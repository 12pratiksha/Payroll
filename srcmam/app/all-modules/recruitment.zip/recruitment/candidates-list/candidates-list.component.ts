import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { AllModulesService } from "../../all-modules.service";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormArray,
} from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { DataTableDirective } from "angular-datatables";
import { DatePipe } from "@angular/common";
import { Router } from "@angular/router";
import { IMultiSelectOption } from 'ngx-bootstrap-multiselect';
import Swal from "sweetalert2";

@Component({
  selector: 'app-candidates-list',
  templateUrl: './candidates-list.component.html',
  styleUrls: ['./candidates-list.component.css']
})
export class CandidatesListComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false })
  public dtElement: DataTableDirective;
  public dtOptions: DataTables.Settings = {};
  public dtTrigger: Subject<any> = new Subject();
  public pipe = new DatePipe("en-US");
  container : boolean = false;
  scheduleContainer : boolean = false 
  candidatesForm: FormGroup
  scheduleForm: FormGroup
  
  myOptions: IMultiSelectOption[];
  candList: any=[];
  employees: any;
  data: any=[];
  candidateId: any;
  constructor(
    private _service: AllModulesService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private _fb: FormBuilder
  ) {}

  ngOnInit() {
   
    // this.candidatesForm = this._fb.group({
    //   name: '',
    //   city:'',
    //   state:'',
    //   dob:'',
    //   email:'',
    //   phone:'',
    //   gender:'',
    //   requiredExp:'',
    //   skills:'',
    //   position:'',
    // })
    this.myOptions = [];
    this.scheduleForm = this._fb.group({
      rounds:'',
      candidateId:'',
      // date:'',
      // time:'',
      fArray: this.formBuilder.array([]) , 
     
    })

    this.dtOptions = {
      pageLength: 10,
      dom: "lrtip",
    };

    this.list();
    this.getEmp()

    //this.scheduleForm.get("rounds")

 
  }

  hideContainer(){
    const currentRoute = this.router.url;

    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]); 
    }); 
    this.container = false
  }

  showContainer(){
   this.container = true
  
  }

  schedule(item){
console.log(item.applicantCandiateListId)
this.candidateId=item.applicantCandiateListId
    this.scheduleContainer = true
    this.container = true
  }

  
  newFarray(): FormGroup{
    return this.formBuilder.group({
      type:'',
      round:'',
      onDate:'',
      atTime:'',
      interview: null,
      // remarkfromHr: '',
      // otherDetails: ''

    })
    }
    // create(): FormGroup{
    // return this.formBuilder.group({
    //   rounds:'',
    // })
    // }

    fArray() : FormArray {
      return this.scheduleForm.get('fArray') as FormArray
      }

      
  
      
  addItem(e): void {  
console.log(e)
    this.fArray().clear()
  
    for (let i = 0; i < e; i ++){
      this.fArray().push(this.newFarray())
       
      }

  }

  // insideArray(farrayindex:number) : FormArray{
  //  // return this.details().at(farrayindex).get("interviewers") as FormArray
  //   }
    
    // newArray(): FormGroup{
    //   return this.formBuilder.group({
    //     empId:'',
    //     remarkfromHr: '',
    //     otherDetails: ''
    //   })
    // }
//   create(): FormGroup {  
//     return this.formBuilder.group({  
//        rounds:'',
       
//     });  
//   } 

// details : FormArray
//   addItem(e): void {  
//     this.details = this.scheduleForm.get('details') as FormArray;  
//     console.log(this.details)
//     while (this.details.length !== 0) {
//       this.details.removeAt(0)
//     }
    
//     for (let i = 0; i < e.length; i ++){
//       this.details.push(this.formBuilder.group({  
//         empid: e[i],  
//          date:'',
//          time:'',
//          type:'',
//       // interviewers:this.fb.array([])
//         // remarkfromHr:'',
//         // otherDetails:''
//       })  );
   
//       console.log(this.details)
//     }
    
//   }  

  getEmp(){
   
    let employees=[]
    let url="employee_master/getemployees"
    this._service.get(url).subscribe((res)=>{
      console.log(res)
    
      // res.forEach(element => {
           
      //   let emp={ id:{"empId":element.employeeId} ,name:element.fullName}
      //   employees.push(emp)
       
        this.employees = res
        
        
      // });
    

      // getGrade(){
  
      //   let grade=[]
       
      //   this._service.get('getgetCodeByType?type=grade').subscribe((res)=>{
          
      //     res.forEach(element => {
           
      //       let grades={id:element.name, name:element.name}
      //       grade.push(grades)
           
      //       this.grade = grade
            
      //     });
          
         
      //   })
      // }
    })

   }
  remark(){
    this.router.navigate(['/layout/recruitment/remarks'])
  }

remove(i){
 // this.details.removeAt(i)
  this.scheduleForm.get('rounds').setValue(this.fArray.length)
}

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }

  onChange(e){
    console.log(e)
  }
  list(){
    let url="getAllApplicantCandiateListList"
    this._service.get(url).subscribe(res=>{
      this.candList=res
      console.log(res)
    })
  }
  download(cvName){
    let url="EditCv"
    const formData = new FormData();
    formData.append('imageName', cvName);
    this._service.add(formData,url).subscribe(res=>{
    console.log(res)
    })  
  }
  open(cvName)
  {
    let url=cvName
    window.open('url');

  }

  submit(){
    console.log(this.candidateId)
    let form=this.scheduleForm.value
    console.log(this.scheduleForm)
     if(this.scheduleForm.status=='VALID'){
    console.log(form)
    let url='AddNoOfRounds'
    //let url="AddScheduleInterviewForRound"
    let data={
    //   "interview": [
    //     {
    //        "interviewer":form.details.interviewer,
    //         "remarkfromHr":form.details.remark,
    //         "otherDetails":form.details.other
    //     },
      
    // ],
    "scheduleInterviewForRound":form.fArray,
    "applicantCandiateId":this.candidateId,
      "roundNo":form.rounds,
    
     // interview
      // "onDate": form.date,
      // "atTime": form.time
  }
  
    this._service.add(data,url).subscribe(res=>{
      console.log(res)
      if(res.respose=='Success')
      {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your work is successfully done',
         
        })
       // this.router.navigate(['/layout/recruitment/candidate'])
        this.list();
        
      }
      else{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
          
        })
      }
    })
    this.scheduleForm.reset();
  }
  else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      
    })
  }


}

  cancel(item){
    //console.log(item)
    let url='deleteApplicantCandiateList/'+item.applicantCandiateListId
    this._service.get(url).subscribe((res)=>{
      if(res.respose=='Success')
      {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your work is successfully done',
         
        })
       this.list();
        
      }
      else{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
          
        })
      }

    })
  }
}
