import { Component, OnInit, ViewChild } from "@angular/core";
import { Router } from "@angular/router";
import { DataTableDirective } from "angular-datatables";
import { Subject } from "rxjs";
import { AllModulesService } from "../../all-modules.service";

@Component({
  selector: 'app-selected-candidates',
  templateUrl: './selected-candidates.component.html',
  styleUrls: ['./selected-candidates.component.css']
})
export class SelectedCandidatesComponent implements OnInit {
  public dtElement: DataTableDirective;
  public dtOptions: DataTables.Settings = {};
  public dtTrigger: Subject<any> = new Subject();
  public lstFees: any[];
  tableData: any=[];

  constructor(
    private _service: AllModulesService,
    public router: Router
    ) { }

  ngOnInit() {

    // for data table configuration
    this.dtOptions = {
      // ... skipped ...
      pageLength: 10,
      dom: "lrtip",
    };
    this.getTableData()
  }



  offer(item){
    console.log(item.applicant_candiate_list_id)
    localStorage.setItem('applicant_candiate_list_id',item.applicant_candiate_list_id)
  this.router.navigate(['/layout/recruitment/offer'])
  
}


  // destroy data table when leaving
  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  getTableData(){
    let url='getSelectedCandiateList'
    this._service.get(url).subscribe(res=>{
      console.log(res)
      this.tableData=res
    })
  }

}
