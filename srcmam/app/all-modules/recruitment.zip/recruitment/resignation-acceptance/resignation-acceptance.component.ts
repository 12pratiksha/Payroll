import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllModulesService } from '../../all-modules.service';

@Component({
  selector: 'app-resignation-acceptance',
  templateUrl: './resignation-acceptance.component.html',
  styleUrls: ['./resignation-acceptance.component.css']
})
export class ResignationAcceptanceComponent implements OnInit {
  showMyContainer : boolean = false
  resigationForm: FormGroup
  tableData: any=[];
  dtOptions: { pagingType: string; pageLength: number; processing: boolean; dom: string; buttons: string[]; };
  constructor(
    public router: Router,
    public fb: FormBuilder,
    public service:AllModulesService
    ) { }



  ngOnInit(): void {
    this.resigationForm = this.fb.group({
      lastDate:'',
      exitConcern:'',
      docClearance:'',
      remark:'',
      other:'',
      assets:'',
    })


    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'print', 
        ]
    };
    this.getAll();
  }
  check(){
    this.showMyContainer = true
    }
    hideContainer(){
      const currentRoute = this.router.url;
    
      this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          this.router.navigate([currentRoute]); // navigate to same route
      }); 
    }
    getAll(){
      let url="getResignationFormList"
      this.service.get(url).subscribe((res)=>{
      this.tableData=res
      })
    
    }
}
