import { Component, OnInit, ViewChild } from '@angular/core';
import { CKEditor5, CKEditorComponent, ChangeEvent } from '@ckeditor/ckeditor5-angular';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
@Component({
  selector: 'app-create-template',
  templateUrl: './create-template.component.html',
  styleUrls: ['./create-template.component.css']
})
export class CreateTemplateComponent implements OnInit {
  @ViewChild( 'editor' ) editorComponent: CKEditorComponent;
  public Editor = ClassicEditor;

 private editor: CKEditor5.Editor;
  text: string;
  constructor() { }

  ngOnInit(): void {
  }
  public onChange( { editor }: ChangeEvent ) {
    const data = editor.getData();

    console.log( data );
}
 
}
