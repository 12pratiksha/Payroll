import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-evalutionform',
  templateUrl: './evalutionform.component.html',
  styleUrls: ['./evalutionform.component.css']
})
export class EvalutionformComponent implements OnInit {
  candidateEvolutionForm:FormGroup
  constructor(public fb:FormBuilder) { }

  ngOnInit(): void {
    this.candidateEvolutionForm=this.fb.group({
      date:['',Validators.required],
      firstName:['',Validators.required],
      surname:['',Validators.required]
    })
  }

}
