import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AllModulesService } from '../../all-modules.service';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import Swal from 'sweetalert2';
//import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-resignation-form',
  templateUrl: './resignation-form.component.html',
  styleUrls: ['./resignation-form.component.css']
})
export class ResignationFormComponent implements OnInit {
  resignForm:FormGroup
  resigationForm:FormGroup
  showMyContainer:boolean=false;
  newForm:boolean=false;
  employee: any=[];
  tableData: any=[];
  dtOptions: { pagingType: string; pageLength: number; processing: boolean; dom: string; buttons: string[]; };
  resignId: boolean;
  constructor(public fb:FormBuilder, public service:AllModulesService,public router:Router) { }

  ngOnInit(): void {
    this.resignForm=this.fb.group({
      employee:'',
      hod:'',
      type:'',
      reason:'',
      resignDate:'',
      requestDate:'',
      releavingDate:'',
      remark:''
    })
this.resigationForm=this.fb.group({
  lastDate:'',
  exitConcern:'',
  docClearance:'',
  remark:'',
  other:'',
  assets:'',
})


    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'print', 
        ]
    };
    this.getemp();
    this.getAll();
  }
  // open()
  // {
  //   this.newForm=true
  // }
  showContainer(){
    this.showMyContainer=true
    
    }
    hideContainer(){
     
    this.showMyContainer=false
    this.cancel()
    
    }

    cancel(){
      const currentRoute = this.router.url;
  
      this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          this.router.navigate([currentRoute]); 
      }); 
    }
submit(){
  let form=this.resignForm.value
let url="InsertResignationForm"
let data={
  "employeeName":form.employee,
    "hod":form.hod,
    "seperationType":form.type,
    "resignationReason":form.reason,
    "dateOfResignation":form.resignDate,
    "requestReleavingDate":form.requestDate,
    "actualReleavingDate":form.releavingDate,
    "remark":form.remark
}
if(this.resignForm.status=='VALID'){
    this.service.add(data,url).subscribe((res)=>{
      console.log(res)
      if(res.respose=='Success')
      {
        Swal.fire({
          icon: 'success',
          title: 'Success',
          text: 'Your work is successfully done',
         
        })
        this.showMyContainer=false 
       this.getAll();
       
      }
      else if(res.respose=='Already')
      {
        Swal.fire({
          icon: 'warning',
          title: 'Oops',
          text: res.message,
         
        })
      }
      else{
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: 'Something went wrong!',
          
        })
      }
   
       
    })
  }
  else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      
    }) 
  }
}

getemp(){
  let url="employee_master/getemployees"
  this.service.get(url).subscribe((res)=>{
 this.employee=res 
  })

}
getAll(){
  let url="getResignationFormList"
  this.service.get(url).subscribe((res)=>{
    this.tableData=res

  })
}
delete(item){
  Swal.fire({
    title:"Are you really wants to delete..?",
    //  html: `<textarea id="login" class="swal2-input" placeholder="Reason" tabIndex="" >`,
    showCancelButton:true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes'
  }).then(result=>{
    console.log(result);
    if(result.isConfirmed==true)
    {
  let url="deleteResignationForm/"+item.resignationFormId
  this.service.get(url).subscribe((res)=>{
    if(res.respose=='Success')
    {
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'resignation form is deleted successfully',
       
      })
      this.showMyContainer=false 
     this.getAll();
     
    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        
      })
    }
  })

}
else{
  this.getAll();
}
  })
}
edit(item){
  this.showMyContainer=true
  this.resignId=item.resignationFormId
 
  let url="getResignationFormById/"+this.resignId 
this.service.get(url).subscribe((res)=>{

var datePipe=new DatePipe('en-Us')
let resignDate=datePipe.transform(res.dateOfResignation,'yyyy-MM-dd')
let requestDate=datePipe.transform(res.requestReleavingDate,'yyyy-MM-dd')
let releavingDate=datePipe.transform(res.actualReleavingDate,'yyyy-MM-dd')
  this.resignForm.get('employee').setValue(res.employeeName)
  this.resignForm.get('hod').setValue(res.hod)
  this.resignForm.get('type').setValue(res.seperationType) 
  this.resignForm.get('resignDate').setValue(resignDate)
  this.resignForm.get('requestDate').setValue(requestDate)
  this.resignForm.get('releavingDate').setValue(releavingDate)
  this.resignForm.get('remark').setValue(res.remark)
  this.resignForm.get('reason').setValue(res.resignationReason)
})
}
update(id){
  let url="updateResignationForm/"+id
  let form=this.resignForm.value
  let data={
    "employeeName":form.employee,
      "hod":form.hod,
      "seperationType":form.type,
      "resignationReason":form.reason,
      "dateOfResignation":form.resignDate,
      "requestReleavingDate":form.requestDate,
      "actualReleavingDate":form.releavingDate,
      "remark":form.remark
  }
  if(this.resignForm.status=='VALID'){

  
  this.service.add(data,url).subscribe((res)=>{
    this.router.navigate(['layout/recruitment/resignation'])
    if(res.respose=='Success')
    {
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: 'Your resignation form is updated successfully',
       
      })
      this.showMyContainer=false 
     this.getAll();
     
    }
    else if(res.respose=='Already')
    {
      Swal.fire({
        icon: 'warning',
        title: 'Oops',
        text: res.message,
       
      })
    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        
      })
    } 
  })
}
  else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
      
    })
  }
  
}
approve(item){
  //let url="ApprovalbyResignationd?ResignationFormId=423092"
  let params = new HttpParams();

params = params.append('ResignationformId', item.resignationFormId);

let url ='ApprovalbyResignationd?ResignationFormId='+`${item.resignationFormId}`
Swal.fire({
  title:"Are you really wants to approve..?",
  //  html: `<textarea id="login" class="swal2-input" placeholder="Reason" tabIndex="" >`,
  showCancelButton:true,
  confirmButtonColor: '#3085d6',
  cancelButtonColor: '#d33',
  confirmButtonText: 'Yes'
}).then(result=>{
  console.log(result);
  if(result.isConfirmed==true)
  {
    this.service.get(url).subscribe((res) => {
      if(res.respose=='Success')
    {
      Swal.fire({
        icon: 'success',
       // title: '',
        text: 'Resignation has been accepted',
       
      })
      
      this.getAll();
    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        
      })
    }
    })
  }
  else if(result.isConfirmed==false)
  {
    this.getAll();
  }
    
})
}
check(){
  this.newForm=true
  }
  
}