import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { AllModulesService } from "../../all-modules.service";
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormArray,
} from "@angular/forms";
import { ToastrService } from "ngx-toastr";
import { Subject } from "rxjs";
import { DataTableDirective } from "angular-datatables";
import { DatePipe } from "@angular/common";
import { Router } from "@angular/router";
import Swal from "sweetalert2";
import { HttpParams } from "@angular/common/http";

declare const $: any;
@Component({
  selector: 'app-new-requirement',
  templateUrl: './new-requirement.component.html',
  styleUrls: ['./new-requirement.component.css']
})
export class NewRequirementComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false })
  public dtElement: DataTableDirective;
  public dtOptions = {};
  public dtTrigger: Subject<any> = new Subject();
  public pipe = new DatePipe("en-US");
  container : boolean = true;
  approved: boolean = false
  jobForm: FormGroup
  department: any;
  designation: any;
  approver: any;
  branch: any;
  customPatterns = {
    V: { pattern: new RegExp("-?") },
    "0": { pattern: new RegExp("[0-9]") },
  };
  editId: any;
  agencyList: any=[];
  item: any=[];
  constructor(
    private _service: AllModulesService,
    private formBuilder: FormBuilder,
    private toastr: ToastrService,
    private router: Router,
    private _fb: FormBuilder
  ) {}

  ngOnInit() {
    this.getTableData()
   this.getDesignation()
   this.getDepartment()
   this.getApprover()
   this.getBranch()
  
   this.getAgencyList()
    this.jobForm = this._fb.group({
      requestDate: ['',Validators.required],
      newRequest: new FormArray([])  
    })
  
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'print', 
        ]
    };

  }

  hideContainer(){
    const currentRoute = this.router.url;

    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]); 
    }); 
    this.container = true
  }

  // showContainer(){
  //  this.container = false
  // }
   
  showContainer(id, type){
    this.router.navigate(['layout/recruitment/recruitmentForm/'+id+'/'+type]); 
   }

  createRequest(): FormGroup {  
    return this.formBuilder.group({  
      department:['',],
       approver:['',],
       noOfVacancy:['',Validators.required],
       jobDescription:['',Validators.required],
       designation:['',],
       expectedJoiningDate:['',Validators.required],
       requiredExp:['',Validators.required],
       requiredGender:['',],
       otherRequirements:['',Validators.required],
       passport:['',],
       ageGroupFrom: ['',Validators.required],
       toAgeGroup:['',Validators.required],
       location:['',Validators.required],
       skills:['',Validators.required],
    });  
  }   
  newRequest: FormArray
  addRequest(): void {  
    this.newRequest = this.jobForm.get('newRequest') as FormArray;  
    this.quantities().push(this.createRequest());  
    console.log(this.newRequest)
  }  



  remove(i:number) {
    // this._service.get("getAllNONApprovalJobRequirementList").subscribe((res)=>{
    //   this.tableData = res.requirement
    //   console.log(res)
    //   if(res.requirement.length==0){
   console.log(i)
   this.quantities().removeAt(i);
    
        //  let url="deleteRequirement/"+
        //  this._service.get(url).subscribe(res=>{
          
        //  })
    
  }
add(type){
  
  let  url
if(type == 'add'){
url = "AddNewRequirementMaster"
}
else{
  //'updateNewRequirement?newRequirementId='+this.tableDatanew_requirement_id+'&this.tableDatarequirementId='+requirement_id
 url = 'updateNewRequirement?newRequirementId='+this.item.new_requirement_id+'&requirementId='+this.item.requirement_id
}
    let form = this.jobForm.value
    console.log(form)
 if(this.jobForm.valid){
 
  let data = {
    requestDate:form.requestDate,
    requirement: this.jobForm.value.newRequest,
   
    // status:"pending",
    // requirementDetais: form.newRequest
  }
this._service.add(data, url).subscribe((res)=>{
if(res.respose == "Success"){
  Swal.fire({
    icon: 'success',
    title: 'Your work has been saved',
    showConfirmButton: false,
    timer: 1500
  })
  const currentRoute = this.router.url;

  this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]);
  }); 
}
else if(res.respose == "Already"){
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'Record Already Exists!',

  })
 }
 else{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'Something went wrong!',

  })
 }
})
 }
 else{
  Swal.fire({
    icon: 'error',
    title: 'Oops...',
    text: 'Something went wrong!',

  })
  this.jobForm.markAllAsTouched()
 }
  }

getDepartment(){
  this._service.get("getAllDepartment").subscribe((res)=>{
    this.department = res
  })
}
getDesignation(){
  this._service.get("getAllDesignationMaster").subscribe((res)=>{
    this.designation = res
  })
}
getApprover(){
  this._service.get("employee_master/getemployees").subscribe((res)=>{
    this.approver = res
  })
}
getBranch(){
  this._service.get("branch/getBranchList").subscribe((res)=>{
    this.branch = res
  })
}
tableData
// getTableData(){
//   let type=localStorage.get('type')
//   if(type=='Admin')
//   {
//     this._service.get("getAllPendingNewRequirementList").subscribe((res)=>{
//       this.tableData = res
//       console.log(res)
//       res.array.forEach(element => {
//         this.tableData.push(element.requirement[0])
        
//       });
//       console.log(this.tableData)
//     })
//   }
//   else{
//   this._service.get("getAllNewRequirementList").subscribe((res)=>{
//     this.tableData = res
//     console.log(res)
//     res.array.forEach(element => {
//       this.tableData.push(element.requirement[0])
      
//     });
//     console.log(this.tableData)
//   })
// }
// }
getTableData(){
  
  let type=localStorage.getItem('type')
  if(type=='Admin')
  {
    this._service.get("getAllPendingNewRequirementList").subscribe((res)=>{
      this.tableData = res
      console.log(res)
      // res.array.forEach(element => {
      //   this.tableData.push(element.requirement[0])
        
      // });
      // console.log(this.tableData)
    })
  }
  else{
  let empid=localStorage.getItem('empid')
  this._service.get("getAllNONApprovalJobRequirementList?empId="+empid).subscribe((res)=>{
    this.tableData = res
    console.log(res)
    // res.forEach(element => {
    //   this.data.push(element.requirement)
     
    // });
    // console.log(this.data)
  })
}
}

ngOnDestroy(): void {
  this.dtTrigger.unsubscribe();
}
delete(id){
  
  Swal.fire({
    title: 'Are you sure?',
   // text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'Loading...',
        allowEscapeKey: false,
        allowOutsideClick: false,
        showConfirmButton: false,
        didOpen: () => {
          Swal.showLoading()
        }
      })
      let url="deleteNewRequirement/"+id
  this._service.get(url).subscribe((res)=>{
      // this._service.delete(id, 'deleteRequirement').subscribe((res)=>{
        if(res.respose=="Success"){
          Swal.fire({
      
            icon: 'success',
            title: 'Job Requirement Deleted Successfully',
            showConfirmButton: false,
            timer: 1500,
            didOpen: () => {
              Swal.hideLoading()
            }
          })
         this.getTableData();

          // // const currentRoute = this.router.url;
  
          // // this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          // //     this.router.navigate([currentRoute]); 
          // }); 
        }
        else{
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Something went wrong',
            didOpen: () => {
              Swal.hideLoading()
            }
          })
        }
      })
    }
  })

}
quantities() : FormArray {
  return this.jobForm.get('newRequest') as FormArray;  
}

edit(item){
  this.item=item
  console.log(item.new_requirement_id)
  this.container = false
  this.editId = item.new_requirement_id
  var datePipe = new DatePipe('en-US');
this._service.get('getByNewRequirementId/'+this.editId).subscribe((res)=>{
  console.log(res)
  let reqDate = datePipe.transform(res.requestDate, 'yyyy-MM-dd');
this.jobForm.get('requestDate').setValue(reqDate)

res.requirement.forEach(element => {
  console.log(element)
  let jDate = datePipe.transform(element.expectedJoiningDate, 'yyyy-MM-dd');
this.quantities().push(this._fb.group({
  department: element.department,
  approver: element.approver,
  noOfVacancy: element.noOfVacancy,
  jobDescription:element.jobDescription,
  designation:element.designation,
  expectedJoiningDate:jDate,
  requiredExp:element.requiredExp,
  requiredGender:element.requiredGender,
  otherRequirements:element.otherRequirements,
  passport:element.passport,
  ageGroupFrom: element.ageGroupFrom,
  toAgeGroup:element.toAgeGroup,
  location:element.location,
  skills:element.skills,
}))
});
})
}

approve(id){
  Swal.fire({
    title: 'Are you sure?',
    // text: "You won't be able to revert this!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, approve it!'
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: 'Loading...',
        allowEscapeKey: false,
        allowOutsideClick: false,
        showConfirmButton: false,
        didOpen: () => {
          Swal.showLoading()
        }
      })
  this.approved=true
  console.log(this.approved)
  console.log(id)
  

  let params = new HttpParams();

  params = params.append('status', this.approved);
  params = params.append('requirementId', id);

  let url='JobRequirementApprovalAPI?status='+`${this.approved}`+'&requirementId='+`${id}`
this._service.add(params,url).subscribe(res=>{
  console.log(res)
  if(res.respose=="Success"){
    Swal.fire({

      icon: 'success',
      title: 'Requirement Approved',
      showConfirmButton: false,
      timer: 1500,
      didOpen: () => {
        Swal.hideLoading()
      }
    })
   this.getTableData();
    const currentRoute = this.router.url;

    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]); 
    }); 
  }
  else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong',
      didOpen: () => {
        Swal.hideLoading()
      }
    })
  }
})
}
})

}
getAgencyList()
{
  let url='getAgencyMasterList'
  this._service.get(url).subscribe(res=>{
    this.agencyList=res
  
  })
}
}
