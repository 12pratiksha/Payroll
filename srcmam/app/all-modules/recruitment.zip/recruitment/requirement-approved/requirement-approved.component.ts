import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllModulesService } from '../../all-modules.service';
import { DatePipe } from '@angular/common';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-requirement-approved',
  templateUrl: './requirement-approved.component.html',
  styleUrls: ['./requirement-approved.component.css']
})
export class RequirementApprovedComponent implements OnInit {
  showMyContainer : boolean = false
  candidatesForm: FormGroup
  public dtOptions = {};
  tableData: any;
  uploadDoc: any;
  reqId: any;
  city: any=[];
  state: any=[];
  qualification: any=[];
  Desingation: any=[];
  candName: any=[];
  department: any;
  agencyList: any=[];
  data: any=[];
  constructor(
    public router: Router,
    public fb: FormBuilder,
    public _service: AllModulesService
    ) { }

  ngOnInit(): void {

this.candidatesForm = this.fb.group({
  candidate:['', Validators.required],
  name:['', Validators.required],
  agency:[''],
  // agencyType:'',
  city: '',
  state: '',
  dob:'',
  email:'',
  phone:'',
  from:'',
  to:'',
  gender:'',
  experience:'',
  skill:"",
  availability:'',
  existing:'',
  qualification:'',
  replacement:[''],
  against: ''
  
})
console.log(this.candidatesForm)
this.dtOptions = {
  pageLength: 10,
  dom: "lrtip",
};
this.getcad()
this.getTableData()
    this.getCity()
    this.getState()
    this.getquali()
    
    this.getDesignation()
    this.getDept()
    this.getAgencyList()
  }
  enterCand(item)
  {
    console.log(item.requirement_id)
    let id=item.requirement_id
this.showMyContainer = true
console.log(id)
this.reqId=id

  this._service.get('getByRequirementId/'+id).subscribe((res)=>{
    this.data=res
  
  })
}
hideContainer(){
  const currentRoute = this.router.url;

  this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]); // navigate to same route
  }); 
}

getTableData(){
  this._service.get("getAllApprovalJobRequirementList").subscribe((res)=>{
    this.tableData = res
    console.log(res)
  })
}
getCity(){
  let url="city/getCityList"
  this._service.get(url).subscribe((res)=>{
    console.log(res)
    this.city=res

  })
}
getState(){
  let url="state/getStateList"
  this._service.get(url).subscribe((res)=>{
this.state=res
  })

}
getcad(){
  let url='getAllApplicantCandiateListList'
  this._service.get(url).subscribe(res=>{
    console.log(res)
    this.candName=res
  })
}
getquali(){
  let url='getgetCodeByType?type=Qualification'
  this._service.get(url).subscribe((res)=>{
console.log(res)
this.qualification=res
  })
}
getDesignation(){
  let url='getAllDesignationMaster'
  this._service.get(url).subscribe((res)=>{
    this.Desingation=res
    console.log(this.Desingation)
  })
}
getDept(){
  let url='getAllDepartment'
  this._service.get(url).subscribe(res=>{
    this.department=res
  })
}
// handleUpload(event) {
 
//   const file = event.target.files[0];

  
//     const formData = new FormData();
//     formData.append('file', file);
//     console.log(file)
//     this.srvModuleService.uploadFile(formData,"employee_master/uploadlogo").subscribe((res)=>{
      
//      this.profilePhoto = res.data[0].firstName
//      console.log( this.profilePhoto )
    
//     //  this.imagePath = this.baseUrl+""+res.data[0].photo
//     //  console.log(this.imagePath)
//     })
  

// }
myfile:any;
uploadFile(event) {
  console.log(event)
  let file = event.target.files[0];
      const formData = new FormData();
    formData.append('file', file);
    console.log(file)
    this._service.uploadFile(formData,"uploadCandidateDoc").subscribe((res)=>{
       console.log(res.data)
       this.uploadDoc = res.data
//   this.myfile=file;
    })
}
add(){

  let formValue=this.candidatesForm.value
  if( formValue.candidate=='New'){
  console.log(formValue.dob);
  var datePipe = new DatePipe('en-US');

   let birthDate = datePipe.transform(formValue.dob, 'yyyy-MM-dd');
   let availableDate = datePipe.transform(formValue.availability, 'yyyy-MM-dd');
  // var birthDate = (new Date(formValue.dob)).toUTCString();

  // var availableDate = (new Date(formValue.availability)).toUTCString();

  console.log(birthDate)
  let url="EnterCandiate"
//   const formData = new FormData();
//   formData.append('selectCandidate', formValue.candidate);
//   formData.append('Replacement', formValue.replacement);
//  formData.append('agency',formValue.agency );
// // formData.append('agencyType', formValue.agencyType);
//  formData.append('state', formValue.state);
//  formData.append('city', formValue.city);
//  formData.append('fullName', formValue.name);
//  formData.append('qualification', formValue.qualification);
//  formData.append('dateOfBirth', birthDate);
//  formData.append('email', formValue.email);
//  formData.append('Phone', formValue.phone);
//  formData.append('age', formValue.from);
//  //formData.append('ageGroupto', formValue.to);
//  formData.append('gender', formValue.gender);
//  formData.append('skills', formValue.skill);
//  formData.append('experience', formValue.experience);
//  formData.append('availability', availableDate);
 
// //formData.append('', edata);
//  formData.append('cv',  this.myfile);
//  formData.append('against', formValue.against);
//  formData.append('requirementId', this.reqId);
let data={
  "selectCandidate": formValue.selectCandidate,
    "Replacement": formValue.replacement,
    "agency": formValue.agency,
    "agencyType":formValue.agencyType,
    "state": formValue.state,
    "city": formValue.city,
    "fullName": formValue.name,
    "qualification": formValue.qualification,
    "dateOfBirth": birthDate,
    "email": formValue.email,
    "phone": formValue.phone,
    "age": formValue.age,
    "gender": formValue.gender,
    "skills": formValue.skill,
    "cvName":  this.uploadDoc ,
    "experience": formValue.experience,
    "availability": availableDate,
    "against": formValue.against,
    "requirementId": this.reqId,
    // "status": "1"
}

 this._service.add(data,url).subscribe(res=>{
  console.log(res)
  if(res.respose == "Success"){
    Swal.fire({
      icon: 'success',
      title: 'Your work has been saved',
      showConfirmButton: false,
      timer: 1500
    })
    const currentRoute = this.router.url;
  
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]);
    }); 
  }
  else if(res.respose == "Already"){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Record Already Exists!',
  
    })
   }
   else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
  
    })
   }
 })
  }
  else{
  console.log(formValue.dob);
  var datePipe = new DatePipe('en-US');

   let birthDate = datePipe.transform(formValue.dob, 'yyyy-MM-dd');
   let availableDate = datePipe.transform(formValue.availability, 'yyyy-MM-dd');
  // var birthDate = (new Date(formValue.dob)).toUTCString();

  // var availableDate = (new Date(formValue.availability)).toUTCString();

  console.log(birthDate)
  let url="EnterCandiate"
//   const formData = new FormData();
//   formData.append('selectCandidate', formValue.candidate);
//   formData.append('Replacement', formValue.replacement);
//  formData.append('agency','null');
// // formData.append('agencyType', formValue.agencyType);
//  formData.append('state', 'null');
//  formData.append('city', 'null');
//  formData.append('fullName', 'null');
//  formData.append('qualification', 'null');
//  formData.append('dateOfBirth', 'null');
//  formData.append('email', 'null');
//  formData.append('Phone', 'null');
//  formData.append('age', '0');
//  //formData.append('ageGroupto', formValue.to);
//  formData.append('gender', 'null');
//  formData.append('skills', 'null');
//  formData.append('experience','0');
//  formData.append('availability', 'null');
 
// //formData.append('', edata);
//  formData.append('cv',  '');
//  formData.append('against', 'null');
//  formData.append('requirementId', this.reqId);
let data={
  "selectCandidate": formValue.selectCandidate,
    "Replacement": formValue.replacement,
    " agency": formValue.agency,
    " agencyType":formValue.agencyType,
    " state": formValue.state,
    " city": formValue.city,
    " fullName": formValue.name,
    " qualification": formValue.qualification,
    "dateOfBirth": birthDate,
    " email": formValue.email,
    " phone": formValue.phone,
    "age": formValue.age,
    " gender": formValue.gender,
    " skills": formValue.skill,
    " cvName":  this.uploadDoc ,
    "experience": formValue.experience,
    "availability": availableDate,
    " against": formValue.against,
    "requirementId": this.reqId,
    // "status": "1"
}

 this._service.add(data,url).subscribe(res=>{
  console.log(res)
  if(res.respose == "Success"){
    Swal.fire({
      icon: 'success',
      title: 'Your work has been saved',
      showConfirmButton: false,
      timer: 1500
    })
    const currentRoute = this.router.url;
  
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]);
    }); 
  }
  else if(res.respose == "Already"){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Record Already Exists!',
  
    })
   }
   else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
  
    })
   }
 })
  }
}
getAgencyList()
{
  let url='getAgencyMasterList'
  this._service.get(url).subscribe(res=>{
    this.agencyList=res
  
  })
}


}

// const formData = new FormData();

//  let edata="{\"assetName\":\""+formValue.assetName+"\",\"assetValue\":\""+formValue.assetValue+"\",\"description\":\""+formValue.description+"\",\"issueDate\":\""+date+"\",\"officeUse\":\""+formValue.givenFor+"\",\"isTermsAndCondition\":\""+formValue.tandc+"\",\"isStatus\":"+formValue.status+",\"isRepeatAsset\":"+formValue.repeatAsset+",\"employeeId\":\""+this.employeeID+"\"}";

//  formData.append('emplAssAssgn', edata);
//  formData.append('attachment', this.uploadAssetfile);
