import { Component, OnInit } from '@angular/core';
import { FormGroup,FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllModulesService } from '../../all-modules.service';
import { ReactiveFormsModule } from '@angular/forms';
import Swal from 'sweetalert2';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-offer',
  templateUrl: './offer.component.html',
  styleUrls: ['./offer.component.css']
})
export class OfferComponent implements OnInit {
  offerForm:FormGroup
  details: any=[];
  bloodGroup: any=[];
  categories: any=[];
  departments: any=[];
  religion: any=[];
  grade: any=[];
  contractorData: any=[];
  company: any=[];
  lstEmployee: any=[];
  branchList: any=[];
  constructor(public router: Router,public _fb:FormBuilder, private _service: AllModulesService,) { }
 
  ngOnInit(): void {

    this.offerForm = this._fb.group({
      experienceChecked:'',
      document1:'',
      attachDoc1:'',
      document2:'',
      attachDoc2:'',
      document3:'',
      attachDoc3:'',
      expected:'',
      offerAccepted:['',Validators.required],
      rDocument1:'',
      rDocument2:'',
      rDocument3:'',
      availablity:['',Validators.required],
      joiningDate:['',Validators.required],
      Offered:'',
      employeeCode:['',Validators.required],
      panno:['',Validators.required],
      grade:['',Validators.required],
      religion:['',Validators.required],
      bloodGroup:['',Validators.required],
      categories:['',Validators.required],
      department:['',Validators.required],
      branch:['',Validators.required],
      permanantadd:['',Validators.required],
      whatsappno:'',
      emgcontactno:'',
      reportingManager:['',Validators.required],
      reportingManager2:['',Validators.required],
      probation:'',
      probationDate:''

    })
console.log(this.offerForm)
    this.getDetails()
    this.getBloodGroup()
    this.getGrade()
    this.contractor()
    this.getCategories()
    this.getCompany()
    this.department()
    this.getReligion()
    this.loadEmployee()
    this.getBranch()
    

  }


  hideContainer(){
   this.router.navigate(['/layout/recruitment/selected']);
   
  }

  getBranch(){

    this._service.get('branch/getBranchList')
    .subscribe((res)=>{
    
    this.branchList = res
    
    })
    
    }
  getBloodGroup(){
    this._service.get('getgetCodeByType?type=bloodGroup').subscribe((res)=>{
    this.bloodGroup = res
   // console.log(res)
    })
  }
  getCategories(){
    this._service.get('categories/getCategories').subscribe((res)=>{
    this.categories=res
  
    })
  }
  department(){
    this._service.get('getAllDepartment').subscribe((res)=>{
    this.departments=res
    })
  }
  
  getReligion(){
    this._service.get('getgetCodeByType?type=religion').subscribe((res)=>{
    this.religion = res
    })
  }
  getGrade(){
    this._service.get('getgetCodeByType?type=grade').subscribe((res)=>{
    this.grade = res
    })
  }
  
  contractor(){
    this._service.get('getgetCodeByType?type=contractor').subscribe((res)=>{
    this.contractorData = res
    })
  }
 
  getCompany(){
    this._service.get('companyMaster/getCompanyList').subscribe((res)=>{
      this.company=res
    })
  }

  loadEmployee() {
    
   
    this._service.get("employee_master/getemployees/").subscribe((data) => {
    
    
      this.lstEmployee = data;

     
      //this.selectedId=data[0].employeeId;
    
    });
  }

  submit()
  {
    var datePipe = new DatePipe('en-US');
  let dateOfBirth = datePipe.transform(this.details.dateOfBirth,'yyyy-MM-dd');
    let url="AddFinalOfferForm"
    let form=this.offerForm.value
    let data={
      " experienceChecked":form.experienceChecked,
      " document1":form.document1,
      "attachDoc1":form.attachDoc1,
      " document2":form.document2,
      "attachDoc2":form.attachDoc2,
      " document3":form.document3,
      "attachDoc3":form.attachDoc3,
      "expected":form.expected,
      " offerAccepted":form.offerAccepted,
      " rDocument1":form.rDocument1,
      " rDocument2":form.rDocument2,
      " rDocument3":form.rDocument3,
      "availablity":form.availablity,
      "joiningDate":form.joiningDate,
      "offered":form.Offered,
      "panNo": form.panno,
      "grade": form.grade,
      "religion":form.religion,
      "bloodGroup": form.bloodGroup,
      "category": form.categories,
      "department": form.department,
      "branch": form.branch,
      "permanentAddress":form.permanantadd,
      "address":this.details.city,
      "mobileNumber": this.details.phone,
      "whatssappNo": form.whatsappno,
      "reportingManager1":form.reportingManager,
      "reportingManager2":form.reportingManager2,
      "probation": form.probation,
      "probationDate": form.probationDate,
      "gender": this.details.gender,
      "experience": this.details.experience,
      "designation": this.details.against,
      "dateOfBirth": dateOfBirth,
      "personalEmailId": this.details.email,
      "employeeCode": form.employeeCode,
      "fullName":this.details.fullName
  }
  this._service.add(data,url).subscribe((res)=>{
    console.log(res)
    if(res.respose == "Success"){
      let id=localStorage.getItem('applicant_candiate_list_id')
      let url='UpdateSelectedStatus?applicantCandiateListId='+id
      this._service.add(data,url).subscribe((res)=>{
        console.log(res)
      })
      Swal.fire({
        icon: 'success',
        title: 'Your work has been saved',
        showConfirmButton: false,
        timer: 1500
      })
      
    }
    else if(res.respose == "Already"){
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Record Already Exists!',
    
      })
     }
     else{
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
    
      })
     }
  })
  const currentRoute = this.router.url;

  this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]);
  }); 
  }
  getDetails(){
    let id=localStorage.getItem('applicant_candiate_list_id')
    let url='getByApplicantCandiateListId/'+id
    this._service.get(url).subscribe((res)=>{
      console.log(res)
      this.details=res
    })
  }

}
