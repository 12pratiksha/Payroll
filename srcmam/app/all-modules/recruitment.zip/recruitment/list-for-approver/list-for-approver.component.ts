import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { AllModulesService } from '../../all-modules.service';
import Swal from 'sweetalert2';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-list-for-approver',
  templateUrl: './list-for-approver.component.html',
  styleUrls: ['./list-for-approver.component.css']
})
export class ListForApproverComponent implements OnInit {
  @ViewChild(DataTableDirective, { static: false })
  public dtElement: DataTableDirective;
  public dtOptions = {};
  public dtTrigger: Subject<any> = new Subject();
  constructor(
    public router: Router,
    public _service: AllModulesService,
  ) { }

  ngOnInit(): void {
    this.getTableData()
    this.dtOptions = {
      pageLength: 10,
      dom: "lrtip",
    };
  }
  showContainer(id,type){
    this.router.navigate(['layout/recruitment/recruitmentForm/'+id+'/'+type]); 
   }
   tableData

getTableData(){
  let empid=localStorage.getItem('empid')
  let url='getAllNONApprovalJobRequirementList?empId='+empid
  this._service.get(url).subscribe((res)=>{
    this.tableData = res
    console.log(res)
  })
}


// let params = new HttpParams();

// params = params.append('year', form.year);
// params = params.append('month', form.month);
// params = params.append('employeeNo', form.employee);
// // console.log(data)

// let url ='JobRequirementApprovalAPI?status='+`${true}`+'&requirementId='+`${i.requirement_id}`

approve(i){
  Swal.fire({
    title:"Are you really wants to approve..?",
    //  html: `<textarea id="login" class="swal2-input" placeholder="Reason" tabIndex="" >`,
    showCancelButton:true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes'
  }).then(result=>{
    console.log(result);
    if(result.isConfirmed==true)
    {
  let params = new HttpParams();
   params = params.append('status', true);
 params = params.append('requirementId', i.requirement_id);
  let url='JobRequirementApprovalAPI?status='+true+'&requirementId='+i.requirement_id
  
  this._service.add(params,url).subscribe((res)=>{
    console.log(res)
    if(res.respose=='Success')
    {
      Swal.fire({
        icon: 'success',
       // title: '',
        text: 'Job requirement has been Approved',
       
      })
      //this.leaveApplicationForm.markAllAsTouched();
      this.getTableData();
    }
    else{
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Something went wrong!',
        
      })
    }

  })
  }
  else if(result.isConfirmed==false)
  {
    this.getTableData();
  }
  })
}
  
  

}
