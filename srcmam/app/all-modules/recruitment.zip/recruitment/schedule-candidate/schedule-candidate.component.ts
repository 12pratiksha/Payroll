import { Component, OnInit } from '@angular/core';
import { AllModulesService } from '../../all-modules.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-schedule-candidate',
  templateUrl: './schedule-candidate.component.html',
  styleUrls: ['./schedule-candidate.component.css']
})
export class ScheduleCandidateComponent implements OnInit {
  public dtOptions = {};
  tableData: any=[];
  inputAdd:string;
  constructor(public service: AllModulesService) { }

  ngOnInit(): void {

this.getList()


    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'print', 
        ]
    };
  }
  getList(){
    let empid=localStorage.getItem('empid')
    let url='getNotSelectedListForApproval?empId='+empid
    this.service.get(url).subscribe((res)=>{
      console.log(res)
      this.tableData=res
    })
  }
  // Swal.fire({
  //   title:"Are you really want reject leave..?",
  //   //  html: `<textarea id="login" class="swal2-input" placeholder="Reason" tabIndex="" >`,
  //    input: 'text',
  //   inputValue: this.inputAdd,
  //   showCancelButton:true,
  //   confirmButtonColor: '#3085d6',
  //   cancelButtonColor: '#d33',
  //   confirmButtonText: 'Yes'
  // }).then(result=>{
  //   console.log(result);
  //   if(result.isConfirmed==true)
  //   {
  //     let id = localStorage.getItem('empid')
  approve(e,item){
    console.log(e)
    if(e==1){
    Swal.fire({
      title:"Are you really want select candidate..?",
      input: 'text',
      inputValue: this.inputAdd,
      showCancelButton:true,
      confirmButtonColor: '#3085d6',
       cancelButtonColor: '#d33',
       confirmButtonText: 'Yes'
    }).then(result=>{
      console.log(result);
      if(result.isConfirmed==true)
      {
    let empid=localStorage.getItem('empid')
    let url='SelectCandiateInInterviewByMananger?status='+1+'&manageempId='+empid+'&NoOfRoundsId='+item.round_id+'&reason='+result.value
    this.service.get(url).subscribe((res)=>{
    console.log(res)
    if(res.respose=='Success')
            {
              Swal.fire({
                icon: 'success',
                title: 'Success',
                text: res.message,
               
              })
            
              this.getList();
            }
            else{
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',
                
              })
            }
    
})
  }
  else{
    this.getList();
  }
})
    }
    else if(e==2){
      if(e==1){
        Swal.fire({
          title:"Are you really want reject candidate..?",
          input: 'text',
          inputValue: this.inputAdd,
          showCancelButton:true,
          confirmButtonColor: '#3085d6',
           cancelButtonColor: '#d33',
           confirmButtonText: 'Yes'
        }).then(result=>{
          console.log(result);
          if(result.isConfirmed==true)
          {
        let empid=localStorage.getItem('empid')
        let url='SelectCandiateInInterviewByMananger?status='+2+'&manageempId='+empid+'&NoOfRoundsId='+item.round_id+'&reason='+result.value
        this.service.get(url).subscribe((res)=>{
        console.log(res)
        if(res.respose=='Success')
                {
                  Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: res.message,
                   
                  })
                
                  this.getList();
                }
                else{
                  Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Something went wrong!',
                    
                  })
                }
        
    })
      }
      else{
        this.getList();
      }
    })
    }
}
}
}
