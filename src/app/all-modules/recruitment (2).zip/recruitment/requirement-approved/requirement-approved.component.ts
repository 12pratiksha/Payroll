import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllModulesService } from '../../all-modules.service';
import { DatePipe, formatDate } from '@angular/common';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-requirement-approved',
  templateUrl: './requirement-approved.component.html',
  styleUrls: ['./requirement-approved.component.css']
})
export class RequirementApprovedComponent implements OnInit {
  showMyContainer : boolean = false
  candidatesForm: FormGroup
  public dtOptions = {};
  tableData: any;
  uploadDoc: any;
  reqId: any;
  city: any=[];
  state: any=[];
  qualification: any=[];
  Desingation: any=[];
  candName: any=[];
  department: any;
  agencyList: any=[];
  data: any=[];
  joiningDate: any;
  tableData_display: any=[];
  approver: any;
  mydata: any;
  requirementlist: any[];
  roundId: any;
  constructor(
    public router: Router,
    public fb: FormBuilder,
    public _service: AllModulesService
    ) { 

      let param=this.router.getCurrentNavigation()?.extras.queryParams;
      if(param){
        this.roundId=JSON.parse(JSON.stringify(param));
        console.log(this.roundId)
        
    
    } 

    }

  ngOnInit(): void {

this.candidatesForm = this.fb.group({
  candidate:['', Validators.required],
  firstName:['', Validators.required],
  middleName:['', Validators.required],
  lastName:['', Validators.required],
  agency:['', Validators.required],
  // agencyType:'',
  city: ['', Validators.required],
  state: ['', Validators.required],
  dob:['', Validators.required],
  email:['', Validators.required],
  phone:['', Validators.required],
  from:['', Validators.required],
  to:['', Validators.required],
  gender:['', Validators.required],
  experience:['', Validators.required],
  skill:['', Validators.required],
  availability:['', Validators.required],
  existing:['', Validators.required],
  qualification:['', Validators.required],
  replacement:[''],
  against: ''
  
})
console.log(this.candidatesForm)
this.dtOptions = {
  pageLength: 10,
  dom: "lrtip",
};
this.getDesignation();
this.getApprover();
this.getcad()
//this.getTableData()
this.getDept()
    this.getCity()
    this.getState()
    this.getquali()
    
    
    
    this.getAgencyList()
  }

  enterCand(item)
  {
    let id=item.requirement_id
this.showMyContainer = true
this.reqId=id

  this._service.get('getByRequirementId/'+id).subscribe((res)=>{
    this.mydata=res
    var datePipe = new DatePipe('en-US');

     this.joiningDate = datePipe.transform(res.expected_joining_date , 'dd-MM-yyyy'); 
     let desg=this.mydata.designation;


       if( isNaN(desg)){
        }else{
         let result3 =this.Desingation.filter((design: any) =>
         (design.designationMasterId==desg) )
       desg = result3[0].name;
        }
        this.mydata.designation=desg;
        
        this.data =this.mydata;
console.log(this.data)

  })
}
hideContainer(){
  const currentRoute = this.router.url;

  this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]); // navigate to same route
  }); 
}

getTableData(){
  this.tableData_display=[];
  this._service.get("getAllApprovalJobRequirementList").subscribe((res)=>{
    this.tableData = res
    console.log(res)
    this.tableData.forEach(element => {

      let desg=element.designation;



        if( isNaN(desg)){
         }else{
          let result3 =this.Desingation.filter((design: any) =>
          (design.designationMasterId==desg) )
        desg = result3[0].name;
         }

      
        this.tableData_display.push({"requirement_id":element.requirement_id,"request_date":element.request_date,"department":element.department_name,"expected_joining_date":element.expected_joining_date,"designation":desg,"no_of_vacancy":element.no_of_vacancy,"approver":element.first_name+" "+element.last_name})
      
    })
  })
}
getCity(){
  let url="city/getCityList"
  this._service.get(url).subscribe((res)=>{
    console.log(res)
    this.city=res

  })
}
getState(){
  let url="state/getStateList"
  this._service.get(url).subscribe((res)=>{
this.state=res
  })

}
getcad(){
  let url='getAllApplicantCandiateListList'
  this._service.get(url).subscribe(res=>{
    console.log(res)
    this.candName=res
  })
}
getquali(){
  let url='getgetCodeByType?type=Qualification'
  this._service.get(url).subscribe((res)=>{
console.log(res)
this.qualification=res
  })
}
async getDesignation(){
  let url='getAllDesignationMaster'
  await this._service.get(url).subscribe((res)=>{
    this.Desingation=res
    this.getTableData();

  })
}

async getApprover(){
  await this._service.get("employee_master/getemployees").subscribe((res)=>{
    this.approver = res
    
    
  })
}

async getDept(){
  let url='getAllDepartment'
  await this._service.get(url).subscribe(res=>{
    this.department=res
  })
}
// handleUpload(event) {
 
//   const file = event.target.files[0];

  
//     const formData = new FormData();
//     formData.append('file', file);
//     console.log(file)
//     this.srvModuleService.uploadFile(formData,"employee_master/uploadlogo").subscribe((res)=>{
      
//      this.profilePhoto = res.data[0].firstName
//      console.log( this.profilePhoto )
    
//     //  this.imagePath = this.baseUrl+""+res.data[0].photo
//     //  console.log(this.imagePath)
//     })
  

// }
myfile:any;
uploadFile(event) {
  console.log(event)
  let file = event.target.files[0];
      const formData = new FormData();
    formData.append('file', file);
    console.log(file)
    this._service.uploadFile(formData,"uploadCandidateDoc").subscribe((res)=>{
       console.log(res.data)
       this.uploadDoc = res.data
//   this.myfile=file;
    })
}
add(){
console.log(this.candidatesForm)
  let formValue=this.candidatesForm.value
  if( formValue.candidate=='New'){
  console.log(formValue.dob);
  let dob=formValue.dob
  
  var datePipe = new DatePipe('en-US');

   let birthDate = datePipe.transform(formValue.dob, 'dd-MM-yyyy');
   let availableDate = datePipe.transform(formValue.availability, 'dd-MM-yyyy');
   const parsedDate1 = new Date(formValue.dob);

const dateArray1 = [
  parsedDate1.getFullYear(),  
  parsedDate1.getMonth() + 1, 
  parsedDate1.getDate()      
];
console.log(dateArray1)

const parsedDate2 = new Date(formValue.availability);

const dateArray2 = [
  parsedDate2.getFullYear(),  
  parsedDate2.getMonth() + 1, 
  parsedDate2.getDate()      
];
  // var birthDate = (new Date(formValue.dob)).toUTCString();

  // var availableDate = (new Date(formValue.availability)).toUTCString();

  console.log(birthDate)
  let url="EnterCandiate"
this.requirementlist=[];
this.requirementlist.push({  "requirementId": this.reqId})
let data={
  "selectCandidate": formValue.selectCandidate,
    "Replacement": formValue.replacement,
    "agency": formValue.agency,
    "agencyType":formValue.agencyType,
    "state": formValue.state,
    "city": formValue.city,
    "firstName": formValue.firstName,
"middleName":formValue.middleName,
"lastName":formValue.lastName,
    "qualification": formValue.qualification,
    "dateOfBirth": dateArray1,
    "email": formValue.email,
    "phone": formValue.phone,
    "age": formValue.age,
    "gender": formValue.gender,
    "skills": formValue.skill,
    "cvName":  this.uploadDoc ,
    "experience": formValue.experience,
    "availability": dateArray2,
    "against": formValue.against,
    "requirementDetails": this.requirementlist,
    // "status": "1"
}
// if(this.candidatesForm.status=='VALID'){


 this._service.add(data,url).subscribe(res=>{
  console.log(res)
  if(res.respose == "Success"){
    Swal.fire({
      icon: 'success',
      title: 'Your work has been saved',
      showConfirmButton: false,
      timer: 1500
    })
    const currentRoute = this.router.url;
  
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]);
    }); 
  }
  else if(res.respose == "Already"){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Record Already Exists!',
  
    })
   }
   else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
  
    })
   }
 })
// }
// else{
//   Swal.fire({
//         icon: 'error',
//         title: 'Oops...',
//         text: 'Something went wrong!',
    
//       })  
// }
//}
// else{
//   Swal.fire({
//     icon: 'error',
//     title: 'Oops...',
//     text: 'Something went wrong!',

//   }) 
//}
  }
  else{
  console.log(formValue.dob);
  var datePipe = new DatePipe('en-US');

   let birthDate = datePipe.transform(formValue.dob, 'dd-MM-yyyy');
   let availableDate = datePipe.transform(formValue.availability, 'dd-MM-yyyy');
  // var birthDate = (new Date(formValue.dob)).toUTCString();

  // var availableDate = (new Date(formValue.availability)).toUTCString();

  console.log(birthDate)
  let url="EnterCandiate"
//   const formData = new FormData();
//   formData.append('selectCandidate', formValue.candidate);
//   formData.append('Replacement', formValue.replacement);
//  formData.append('agency','null');
// // formData.append('agencyType', formValue.agencyType);
//  formData.append('state', 'null');
//  formData.append('city', 'null');
//  formData.append('fullName', 'null');
//  formData.append('qualification', 'null');
//  formData.append('dateOfBirth', 'null');
//  formData.append('email', 'null');
//  formData.append('Phone', 'null');
//  formData.append('age', '0');
//  //formData.append('ageGroupto', formValue.to);
//  formData.append('gender', 'null');
//  formData.append('skills', 'null');
//  formData.append('experience','0');
//  formData.append('availability', 'null');
 
// //formData.append('', edata);
//  formData.append('cv',  '');
//  formData.append('against', 'null');
//  formData.append('requirementId', this.reqId);
let data={
  "selectCandidate": formValue.selectCandidate,
    "Replacement": formValue.replacement,
    " agency": formValue.agency,
    " agencyType":formValue.agencyType,
    " state": formValue.state,
    " city": formValue.city,
    " firstName": formValue.firstName,
    " middleName":formValue.middleName,
    " lastName":formValue.lastName,
    " qualification": formValue.qualification,
    "dateOfBirth": birthDate,
    " email": formValue.email,
    " phone": formValue.phone,
    "age": formValue.age,
    " gender": formValue.gender,
    " skills": formValue.skill,
    " cvName":  this.uploadDoc ,
    "experience": formValue.experience,
    "availability": availableDate,
    " against": formValue.against,
    "requirementId": this.reqId,
    // "status": "1"
}

 this._service.add(data,url).subscribe(res=>{
  console.log(res)
  if(res.respose == "Success"){
    Swal.fire({
      icon: 'success',
      title: 'Your work has been saved',
      showConfirmButton: false,
      timer: 1500
    })
    const currentRoute = this.router.url;
  
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]);
    }); 
  }
  else if(res.respose == "Already"){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Record Already Exists!',
  
    })
   }
   else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
  
    })
   }
 })
  
}
}
getAgencyList()
{
  let url='getAgencyMasterList'
  this._service.get(url).subscribe(res=>{
    this.agencyList=res
  
  })
}


}

// const formData = new FormData();

//  let edata="{\"assetName\":\""+formValue.assetName+"\",\"assetValue\":\""+formValue.assetValue+"\",\"description\":\""+formValue.description+"\",\"issueDate\":\""+date+"\",\"officeUse\":\""+formValue.givenFor+"\",\"isTermsAndCondition\":\""+formValue.tandc+"\",\"isStatus\":"+formValue.status+",\"isRepeatAsset\":"+formValue.repeatAsset+",\"employeeId\":\""+this.employeeID+"\"}";

//  formData.append('emplAssAssgn', edata);
//  formData.append('attachment', this.uploadAssetfile);
