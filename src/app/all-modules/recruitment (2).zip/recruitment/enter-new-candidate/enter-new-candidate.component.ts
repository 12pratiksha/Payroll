import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AllModulesService } from '../../all-modules.service';
import { DatePipe, formatDate } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-enter-new-candidate',
  templateUrl: './enter-new-candidate.component.html',
  styleUrls: ['./enter-new-candidate.component.css']
})
export class EnterNewCandidateComponent implements OnInit {

  showMyContainer : boolean = false
  candidatesForm: FormGroup
  public dtOptions = {};
  tableData: any;
  uploadDoc: any;
  reqId: any;
  city: any=[];
  state: any=[];
  qualification: any=[];
  Desingation: any=[];
  candName: any=[];
  department: any;
  agencyList: any=[];
  data: any=[];
  joiningDate: any;
  tableData_display: any=[];
  approver: any;
  mydata: any;
  requirementlist: any[];
  roundId: any;
  baseurl: string;
  constructor(
    public router: Router,
    public fb: FormBuilder,
    public _service: AllModulesService
    ) { 

    }

  ngOnInit(): void {
    this.baseurl=localStorage.getItem('baseurl')
this.showMyContainer=false;
this.candidatesForm = this.fb.group({
  candidate:['', Validators.required],
  firstName:['', Validators.required],
  middleName:['', Validators.required],
  lastName:['', Validators.required],
  agency:['', Validators.required],
  // agencyType:'',
  city: ['', Validators.required],
  state: ['', Validators.required],
  dob:['', Validators.required],
  email:['', Validators.required],
  phone:['', Validators.required],
  from:['', Validators.required],
  to:['', Validators.required],
  gender:['', Validators.required],
  experience:['', Validators.required],
  skill:['', Validators.required],
  availability:['', Validators.required],
  existing:['', Validators.required],
  qualification:['', Validators.required],
  replacement:[''],
  against: '',
  applicationDate:''
  
})
console.log(this.candidatesForm)
this.dtOptions = {
  pageLength: 10,
  dom: "lrtip",
};
this.getDesignation();
this.getApprover();
this.getcad()
//this.getTableData()
this.getDept()
    this.getCity()
    this.getState()
    this.getquali()
    
    
    
    this.getAgencyList()
  }

  enterCand(item)
  {
    let id=item.requirement_id
this.showMyContainer = true
this.reqId=id

  this._service.get('getByRequirementId/'+id).subscribe((res)=>{
    this.mydata=res
    var datePipe = new DatePipe('en-US');

     this.joiningDate = datePipe.transform(res.expected_joining_date , 'dd-MM-yyyy'); 
     let desg=this.mydata.designation;


       if( isNaN(desg)){
        }else{
         let result3 =this.Desingation.filter((design: any) =>
         (design.designationMasterId==desg) )
       desg = result3[0].name;
        }
        this.mydata.designation=desg;
        
        this.data =this.mydata;
console.log(this.data)

  })
}
showContainer(){
  this.showMyContainer=true
  
  }
hideContainer(){
  this.showMyContainer=false
  const currentRoute = this.router.url;

  this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentRoute]); // navigate to same route
  }); 
}

getTableData(){
  this.tableData_display=[];
  this._service.get("getAllCandiateListWoApplication").subscribe((res)=>{
    this.tableData_display = res
  
  })
}
getCity(){
  let url="city/getCityList"
  this._service.get(url).subscribe((res)=>{
    console.log(res)
    this.city=res

  })
}
getState(){
  let url="state/getStateList"
  this._service.get(url).subscribe((res)=>{
this.state=res
  })

}
getcad(){
  let url='getAllApplicantCandiateListList'
  this._service.get(url).subscribe(res=>{
    console.log(res)
    this.candName=res
  })
}
getquali(){
  let url='getgetCodeByType?type=Qualification'
  this._service.get(url).subscribe((res)=>{
console.log(res)
this.qualification=res
  })
}
async getDesignation(){
  let url='getAllDesignationMaster'
  await this._service.get(url).subscribe((res)=>{
    this.Desingation=res
    this.getTableData();

  })
}

async getApprover(){
  await this._service.get("employee_master/getemployees").subscribe((res)=>{
    this.approver = res
    
    
  })
}

async getDept(){
  let url='getAllDepartment'
  await this._service.get(url).subscribe(res=>{
    this.department=res
  })
}
// handleUpload(event) {
 
//   const file = event.target.files[0];

  
//     const formData = new FormData();
//     formData.append('file', file);
//     console.log(file)
//     this.srvModuleService.uploadFile(formData,"employee_master/uploadlogo").subscribe((res)=>{
      
//      this.profilePhoto = res.data[0].firstName
//      console.log( this.profilePhoto )
    
//     //  this.imagePath = this.baseUrl+""+res.data[0].photo
//     //  console.log(this.imagePath)
//     })
  

// }
myfile:any;
uploadFile(event) {
  console.log(event)
  let file = event.target.files[0];
      const formData = new FormData();
    formData.append('file', file);
    console.log(file)
    this._service.uploadFile(formData,"uploadCandidateDoc").subscribe((res)=>{
       console.log(res.data)
       this.uploadDoc = res.data
//   this.myfile=file;
    })
}
add(){
console.log(this.candidatesForm)
  let formValue=this.candidatesForm.value
  console.log(formValue.dob);
  let dob=formValue.dob
  
  var datePipe = new DatePipe('en-US');

   const parsedDate1 = new Date(formValue.dob);
const dateArray1 = [
  parsedDate1.getFullYear(),  
  parsedDate1.getMonth() + 1, 
  parsedDate1.getDate()      
];
console.log(dateArray1)

const parsedDate2 = new Date(formValue.availability);

const dateArray2 = [
  parsedDate2.getFullYear(),  
  parsedDate2.getMonth() + 1, 
  parsedDate2.getDate()      
];

const parsedDate3 = new Date(formValue.applicationDate);

const dateArray3 = [
  parsedDate3.getFullYear(),  
  parsedDate3.getMonth() + 1, 
  parsedDate3.getDate()      
];
  // var birthDate = (new Date(formValue.dob)).toUTCString();

  // var availableDate = (new Date(formValue.availability)).toUTCString();

  let url="EnterCandiate"
this.requirementlist=[];
this.requirementlist.push({  "requirementId": this.reqId})
let data={
  "selectCandidate": formValue.selectCandidate,
    "Replacement": formValue.replacement,
    "agency": formValue.agency,
    "agencyType":formValue.agencyType,
    "state": formValue.state,
    "city": formValue.city,
    "firstName": formValue.firstName,
"middleName":formValue.middleName,
"lastName":formValue.lastName,
    "qualification": formValue.qualification,
    "dateOfBirth": dateArray1,
    "email": formValue.email,
    "phone": formValue.phone,
    "age": formValue.age,
    "gender": formValue.gender,
    "skills": formValue.skill,
    "cvName":  this.uploadDoc ,
    "experience": formValue.experience,
    "availability": dateArray2,
    "against": formValue.against,
    "requirementDetails": this.requirementlist,
    "applicationDate":dateArray3
    // "status": "1"
}
// if(this.candidatesForm.status=='VALID'){

console.log(data);

 this._service.add(data,url).subscribe(res=>{
  console.log(res)
  if(res.respose == "Success"){
    Swal.fire({
      icon: 'success',
      title: 'Your work has been saved',
      showConfirmButton: false,
      timer: 1500
    })
    const currentRoute = this.router.url;
  
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
        this.router.navigate([currentRoute]);
    }); 
  }
  else if(res.respose == "Already"){
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Record Already Exists!',
  
    })
   }
   else{
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: 'Something went wrong!',
  
    })
   }
 })
// }
// else{
//   Swal.fire({
//         icon: 'error',
//         title: 'Oops...',
//         text: 'Something went wrong!',
    
//       })  
// }
//}
// else{
//   Swal.fire({
//     icon: 'error',
//     title: 'Oops...',
//     text: 'Something went wrong!',

//   }) 
//}
  
  
}
getAgencyList()
{
  let url='getAgencyMasterList'
  this._service.get(url).subscribe(res=>{
    this.agencyList=res
  
  })
}
}
