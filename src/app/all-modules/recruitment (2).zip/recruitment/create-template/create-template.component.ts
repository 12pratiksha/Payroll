import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { AllModulesService } from '../../all-modules.service';
import { CKEditor5, CKEditorComponent, ChangeEvent } from '@ckeditor/ckeditor5-angular';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
@Component({
  selector: 'app-create-template',
  templateUrl: './create-template.component.html',
  styleUrls: ['./create-template.component.css']
})
export class CreateTemplateComponent implements OnInit {
  @ViewChild( 'editor' ) editorComponent: CKEditorComponent;
  public Editor = ClassicEditor;
  tempForm:FormGroup;

 private editor: CKEditor5.Editor;
  text: string;
  constructor(public fb:FormBuilder,public service:AllModulesService,public router:Router) { }

  ngOnInit(): void {
    this.tempForm=this.fb.group({
      templateName:['',Validators.required],
      type:['',Validators.required],
      template:['',Validators.required]
    })
  }
  public onChange( { editor }: ChangeEvent ) {
    const data = editor.getData();

    console.log( data );
}
submit(){
  let form=this.tempForm.value
  let url="InsertTemplates"
  let content= form.template;
  content = content.replaceAll('{#var}','XVARX');
  let data={
    "templateName":form.templateName,
    "type":form.type,
    "content":form.template,
    "variables":[
        {"Variable":"V1"},
         {"Variable":"V2"}
    ]
}
  this.service.add(data, url).subscribe(res=>{
    console.log(res)
    if(res.respose=='Success'){
      Swal.fire({
        icon:'success',
        title:'Success',
        text:'Your work has been saved!'
      })
      const currentRoute = this.router.url;

      this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          this.router.navigate([currentRoute]); // navigate to same route
      }); 
    }
    else{
      Swal.fire({
        icon:'error',
        title:'Error',
        text:'Something went wrong'
      })

    }
  })

}
}
